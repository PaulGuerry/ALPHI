#!/usr/bin/env Rscript
# MYO5B figure 1: the patients in UMAP space, coloured by pairD cluster (a), and the same
# embedding coloured by the presence of each signature (b intestinal, c cholestatic,
# d liver fibrosis).
#
# Input: PREFIX_patients.csv and PREFIX_clusters.csv from extract_myo5b_figdata.py.
# Usage (in ~/pairD_eval/myo5b):
#   Rscript ../scripts/fig_myo5b_umap.R figdata/ob_nearest -o ../figures/Fig_myo5b_umap_OB
#   Rscript ../scripts/fig_myo5b_umap.R figdata/resnik --distance Resnik -o ../figures/FigS_myo5b_umap_Resnik
# Options: --distance NAME (label in the panel title, default OB)
# Writes OUTPUT.png (600 dpi) and OUTPUT.pdf, 180 mm wide; prints the figure-legend text.
# Requires: ggplot2, patchwork

here <- dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]))
source(file.path(here, "myo5b_fig_common.R"))
opt <- parse_args(list(suffix = "umap", distance = "OB"))

p <- read.csv(paste0(opt$prefix, "_patients.csv"), stringsAsFactors = FALSE)
cl <- read.csv(paste0(opt$prefix, "_clusters.csv"), stringsAsFactors = FALSE)
lev <- cluster_levels(p$cluster)
p$cluster <- factor(p$cluster, levels = lev)
cols <- cluster_colours(lev)

# ---- a: clusters, labelled at their centre (no legend) ---------------------------------------
cen <- aggregate(cbind(umap_x, umap_y) ~ cluster, data = p[p$cluster != "Noise", ], FUN = median)
cen <- merge(cen, cl[, c("cluster", "n", "stability")], by = "cluster")
cen$label <- sprintf("%s\nn = %d", cen$cluster, cen$n)

blank_axes <- theme(axis.text = element_blank(), axis.ticks = element_blank(),
                    panel.grid.major = element_blank())

pa <- ggplot(p, aes(umap_x, umap_y)) +
  geom_point(aes(fill = cluster), shape = 21, colour = "white", stroke = 0.3, size = 2.2, alpha = 0.95) +
  geom_label(data = cen, aes(label = label, colour = cluster), size = 2.8, lineheight = 0.9,
             fill = scales::alpha("white", 0.85), label.size = 0, fontface = "bold") +
  scale_fill_manual(values = cols, guide = "none") +
  scale_colour_manual(values = cols, guide = "none") +
  labs(x = "UMAP 1", y = "UMAP 2", title = paste0("Clusters (", opt$distance, " distance)")) +
  theme_fig() + blank_axes +
  theme(panel.background = element_rect(fill = NA, colour = NA))

# ---- b-d: signatures -------------------------------------------------------------------
feature_panel <- function(var, title, colour) {
  q <- p
  q$present <- factor(ifelse(as.character(q[[var]]) %in% c("True", "TRUE"), "present", "absent"),
                      levels = c("absent", "present"))
  q <- q[order(q$present), ]                      # present drawn on top
  ggplot(q, aes(umap_x, umap_y, fill = present)) +
    geom_point(shape = 21, colour = "white", stroke = 0.2, size = 1.4) +
    scale_fill_manual(values = c(absent = ABSENT, present = colour), guide = "none") +
    labs(x = NULL, y = NULL, title = sprintf("%s (%d / %d)", title, sum(q$present == "present"), nrow(q))) +
    theme_fig(7) + blank_axes +
    theme(plot.title = element_text(size = 7.5, face = "plain"))
}
pb <- feature_panel("intestinal", "Intestinal signature", CLUSTER_COLOURS[["MVID"]])
pc <- feature_panel("cholestatic", "Cholestatic signature", CLUSTER_COLOURS[["PFIC"]])
pd <- feature_panel("fibrosis", "Liver fibrosis", CLUSTER_COLOURS[["MVID+PFIC"]])

g <- pa + pb + pc + pd +
  plot_layout(design = "AAB\nAAC\nAAD") +
  plot_annotation(tag_levels = "a")
save_fig(g, opt$output, 180, 125)

cat("\nFor the figure legend:\n",
    "UMAP embedding of the ", nrow(p), " MYO5B patients (", opt$distance, " distance). ",
    "(a) pairD clusters; (b-d) the same embedding, patients with the intestinal signature ",
    "(diarrhoea, microvillus inclusions or parenteral nutrition), the cholestatic signature ",
    "(cholestasis, hyperbilirubinaemia, jaundice or pruritus) or liver fibrosis (any term below ",
    "Hepatic fibrosis) in colour. The 2-D embedding is for display; clusters were found in ",
    "pairD's 10-D embedding of the same distances.\n", sep = "")
