#!/usr/bin/env Rscript
# MYO5B figure 2: phenotypic make-up of the pairD clusters. Dot plot of symptom prevalence
# (% of patients) per cluster: the expected signature terms (counted with their
# descendants) on top, then the most discriminating reported terms, grouped by organ.
# Column headers give the cluster size, resampling stability and few-feature check.
#
# Input: PREFIX_prevalence.csv and PREFIX_clusters.csv from extract_myo5b_figdata.py.
# Usage (in ~/pairD_eval/myo5b):
#   Rscript ../scripts/fig_myo5b_phenotype.R figdata/ob_nearest -o ../figures/Fig_myo5b_phenotype_OB
# Options: --distance NAME (default OB)
# Writes OUTPUT.png (600 dpi) and OUTPUT.pdf, 180 mm wide; prints the figure-legend text.
# Requires: ggplot2, patchwork

here <- dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]))
source(file.path(here, "myo5b_fig_common.R"))
opt <- parse_args(list(suffix = "phenotype", distance = "OB"))

v <- read.csv(paste0(opt$prefix, "_prevalence.csv"), stringsAsFactors = FALSE)
cl <- read.csv(paste0(opt$prefix, "_clusters.csv"), stringsAsFactors = FALSE)
cl <- cl[cl$cluster != "Noise", ]

lev <- cluster_levels(v$cluster)
cl <- cl[match(lev, cl$cluster), ]
flag_txt <- ifelse(as.character(cl$flag_few_features) %in% c("True", "TRUE"), "FLAGGED", "not flagged")
header <- sprintf("%s\nn = %d\nstability %.2f", cl$cluster, cl$n, cl$stability)
v$cluster <- factor(v$cluster, levels = lev, labels = header)

GROUP_ORDER <- c("Expected signature", "Intestine", "Liver", "Skin", "Growth", "Blood and metabolism", "Other")
v$group <- factor(v$group, levels = intersect(GROUP_ORDER, unique(v$group)))

# within a group: terms ordered by the cluster where they peak, then by prevalence
peak <- aggregate(prevalence ~ term + group, data = v, FUN = max)
v$is_peak <- mapply(function(t, x) x == max(v$prevalence[v$term == t]), v$term, v$prevalence)
peak_cl <- unique(v[v$is_peak, c("term", "cluster")])
peak_cl <- peak_cl[!duplicated(peak_cl$term), ]
peak$peak_cluster <- as.integer(peak_cl$cluster[match(peak$term, peak_cl$term)])
peak <- peak[order(peak$group, peak$peak_cluster, -peak$prevalence), ]
v$term_f <- factor(v$term, levels = rev(unique(peak$term)))

# shorter labels for the long lab terms
v$term_f <- factor(v$term_f, labels = sub("^Elevated circulating ", "Elevated ",
                                          sub(" concentration$", "", levels(v$term_f))))

g <- ggplot(v, aes(cluster, term_f)) +
  geom_point(aes(size = prevalence, fill = prevalence), shape = 21, colour = "white", stroke = 0.3) +
  geom_text(data = v[v$prevalence >= 50, ], aes(label = round(prevalence)), size = 1.9, colour = "white") +
  facet_grid(group ~ ., scales = "free_y", space = "free_y", switch = "y") +
  scale_size_area(max_size = 5.2, limits = c(0, 100), breaks = c(25, 50, 75, 100), name = "Patients (%)") +
  scale_fill_gradient(low = "#c9d9ef", high = "#173f73", limits = c(0, 100), breaks = c(25, 50, 75, 100),
                      name = "Patients (%)") +
  scale_x_discrete(position = "top") +
  labs(x = NULL, y = NULL) +
  theme_fig(7.5) +
  theme(panel.grid.major = element_line(colour = GRID, linewidth = 0.25),
        axis.text.x.top = element_text(colour = INK, size = 7.5, lineheight = 0.95),
        axis.text.y = element_text(colour = INK, size = 7),
        strip.placement = "outside",
        strip.text.y.left = element_text(angle = 0, hjust = 1, face = "bold", size = 7),
        panel.spacing.y = unit(0.35, "lines"),
        legend.position = "right") +
  guides(size = guide_legend(override.aes = list(fill = "#2f5f9e")), fill = "none")

n_rows <- length(unique(v$term))
save_fig(g, opt$output, 180, 30 + 4.3 * n_rows)

cat("\nFor the figure legend:\n",
    "Prevalence of symptoms in the pairD clusters of MYO5B patients (", opt$distance, " distance). ",
    "Expected signature: the terms defining the MVID and PFIC signatures, each counted with its ",
    "descendants. Other rows: the reported terms whose prevalence differs most between clusters ",
    "(at least 30 percentage points), grouped by organ. Dot area and shade: % of patients. ",
    "Stability: mean Jaccard similarity of each cluster over 50 resamples of 80 % of patients. ",
    "Few-feature check: ", paste(sprintf("%s %s", cl$cluster, flag_txt), collapse = ", "),
    " (closest clusters differ on ", paste(cl$n_discriminating, collapse = " / "), " symptoms).\n", sep = "")
